# ClientRadar Android Companion

This is the native Android companion source project for the existing ClientRadar dashboard.

## What it does

- Pairs with the signed-in ClientRadar workspace using a one-time code.
- Requests Android Notification Access through the system settings screen.
- Listens only to notifications from Facebook (`com.facebook.katana`) and Facebook Lite (`com.facebook.lite`).
- Downloads the account's saved search phrases and filters notifications locally.
- Sends only matching notification title/text to ClientRadar over HTTPS.
- Does not send messages, click posts, or contact Facebook users. Every captured opportunity remains for manual review.

## Pairing

1. Open the deployed ClientRadar dashboard and sign in.
2. In the Android companion panel, select **Generate pairing code**.
3. Open this Android app and enter the pairing code before it expires.
4. Tap **Connect to ClientRadar**.
5. Tap **Enable notification access** and enable ClientRadar Companion in Android settings.
6. Allow Facebook notifications to appear on the phone. Matching notifications should appear in the ClientRadar opportunity feed.

Pairing codes expire after five minutes. Generate a new one if needed.

## Build the APK

1. Install Android Studio (current stable release) on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync to finish; use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.

This source archive is not itself an APK. A local Android SDK/Gradle build is required to produce an installable APK.

## Privacy and permissions

Notification Access is a powerful Android permission. ClientRadar Companion reads notification content locally to identify matches. Only matching Facebook/Facebook Lite notifications are sent to the ClientRadar service. The device token is stored using AndroidX encrypted shared preferences. The app does not request access to contacts, photos, microphone, location, or SMS.

The companion currently supports the Facebook Android app and Facebook Lite. It cannot capture Facebook posts that do not generate a device notification, and it cannot guarantee that every Facebook notification contains a clickable post URL.
