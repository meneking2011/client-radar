package ai.clientradar.companion

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.util.Log
import java.util.Locale
import java.util.concurrent.Executors

class FacebookNotificationListener : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()
    private val facebookPackages = setOf("com.facebook.katana", "com.facebook.lite")

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in facebookPackages) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val parts = mutableListOf<String>()
        extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let(parts::add)
        extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.let(parts::add)
        extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { parts.add(it.toString()) }
        val body = parts.map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString("\n")
        if (body.isBlank()) return

        executor.execute {
            val token = SecurePrefs.token(this)
            if (token.isBlank()) return@execute
            try {
                var keywords = SecurePrefs.keywords(this)
                val stale = System.currentTimeMillis() - SecurePrefs.keywordsUpdatedAt(this) > 10 * 60 * 1000
                if (keywords.isEmpty() || stale) {
                    keywords = ApiClient.fetchKeywords(token)
                    SecurePrefs.saveKeywords(this, keywords)
                }
                val searchable = "$title $body".lowercase(Locale.ROOT)
                val matched = keywords.any { phrase ->
                    searchable.contains(phrase.lowercase(Locale.ROOT))
                }
                if (matched) {
                    ApiClient.sendNotification(token, sbn.packageName, title, body)
                }
            } catch (error: Exception) {
                Log.w("ClientRadar", "Notification sync failed: ${error.message}")
            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
