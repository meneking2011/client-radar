package ai.clientradar.companion

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecurePrefs {
    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        "clientradar_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun token(context: Context): String = prefs(context).getString("device_token", "") ?: ""
    fun saveToken(context: Context, token: String) {
        prefs(context).edit().putString("device_token", token).apply()
    }
    fun clearToken(context: Context) {
        prefs(context).edit().remove("device_token").apply()
    }
    fun keywords(context: Context): Set<String> =
        prefs(context).getStringSet("keywords", emptySet())?.toSet() ?: emptySet()
    fun saveKeywords(context: Context, keywords: Set<String>) {
        prefs(context).edit()
            .putStringSet("keywords", keywords)
            .putLong("keywords_updated_at", System.currentTimeMillis())
            .apply()
    }
    fun keywordsUpdatedAt(context: Context): Long =
        prefs(context).getLong("keywords_updated_at", 0L)
}
