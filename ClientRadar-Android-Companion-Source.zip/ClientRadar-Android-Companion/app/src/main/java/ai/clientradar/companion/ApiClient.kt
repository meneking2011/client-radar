package ai.clientradar.companion

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    const val BASE_URL = "https://clientradar-fxrsau.v2.appdeploy.ai"

    fun post(path: String, payload: JSONObject): JSONObject {
        val connection = (URL(BASE_URL + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12000
            readTimeout = 12000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException(JSONObject(response).optString("error", "Request failed (${connection.responseCode})"))
            }
            JSONObject(response)
        } finally {
            connection.disconnect()
        }
    }

    fun exchangeCode(code: String): String {
        val result = post("/api/companion/exchange", JSONObject().put("code", code))
        return result.getString("deviceToken")
    }

    fun fetchKeywords(token: String): Set<String> {
        val result = post("/api/companion/keywords", JSONObject().put("deviceToken", token))
        val array: JSONArray = result.optJSONArray("keywords") ?: JSONArray()
        return buildSet {
            for (i in 0 until array.length()) {
                val phrase = array.optString(i).trim()
                if (phrase.length >= 2) add(phrase)
            }
        }
    }

    fun sendNotification(token: String, packageName: String, title: String, text: String) {
        post(
            "/api/companion/ingest",
            JSONObject()
                .put("deviceToken", token)
                .put("packageName", packageName)
                .put("title", title)
                .put("text", text)
        )
    }
}
