package ai.clientradar.companion

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var codeInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF0B111D.toInt())
        }

        val title = TextView(this).apply {
            text = "ClientRadar Companion"
            textSize = 25f
            setTextColor(0xFFEAF2F7.toInt())
        }
        val intro = TextView(this).apply {
            text = "Connect this phone to your ClientRadar workspace. Only Facebook notifications matching your saved keywords are sent."
            textSize = 15f
            setTextColor(0xFF9EADBD.toInt())
            setPadding(0, 14, 0, 22)
        }
        codeInput = EditText(this).apply {
            hint = "Pairing code from ClientRadar"
            singleLine = true
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF8999AA.toInt())
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFF182536.toInt())
        }
        val connect = Button(this).apply {
            text = "Connect to ClientRadar"
            setOnClickListener { connectDevice() }
        }
        val access = Button(this).apply {
            text = "Enable notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val disconnect = Button(this).apply {
            text = "Disconnect this phone"
            setOnClickListener {
                SecurePrefs.clearToken(this@MainActivity)
                status.text = "This phone has been disconnected. Generate a new code in ClientRadar to reconnect."
            }
        }
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF8EDCCB.toInt())
            setPadding(0, 20, 0, 0)
        }

        listOf(title, intro, codeInput, connect, access, disconnect, status).forEach { view ->
            layout.addView(view, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 12 })
        }
        setContentView(layout)
        status.text = if (SecurePrefs.token(this).isNotBlank()) {
            "Device paired. Enable notification access to begin capture."
        } else {
            "Not connected yet."
        }
    }

    private fun connectDevice() {
        val code = codeInput.text.toString().trim()
        if (!code.matches(Regex("(?i)^[a-z0-9_-]{8,128}$"))) {
            Toast.makeText(this, "Enter the 20-character code from ClientRadar.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Connecting securely…"
        executor.execute {
            try {
                val token = ApiClient.exchangeCode(code)
                SecurePrefs.saveToken(this, token)
                runOnUiThread {
                    codeInput.text.clear()
                    status.text = "Connected. Now enable notification access below."
                    Toast.makeText(this, "ClientRadar connected.", Toast.LENGTH_LONG).show()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    status.text = "Connection failed: ${error.message ?: "Please try again."}"
                }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
